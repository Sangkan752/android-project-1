package com.example.recipeapp.Models;

public class Us {
    public double amount;
    public String unitLong;
    public String unitShort;
}
