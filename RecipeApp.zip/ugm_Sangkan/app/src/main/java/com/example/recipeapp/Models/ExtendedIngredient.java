package com.example.recipeapp.Models;

import java.util.ArrayList;

public class ExtendedIngredient {
    public String aisle;
    public double amount;
    public String consitency;
    public int id;
    public String image;
    public Measures measures;
    public ArrayList<String> meta;
    public String name;
    public String original;
    public String originalName;
    public String unit;
}
