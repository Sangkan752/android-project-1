package com.example.recipeapp.Models;

import java.util.ArrayList;

public class InstructionResponse {
    public String name;
    public ArrayList<Step> steps;
}
